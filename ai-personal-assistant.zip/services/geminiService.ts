
import { GoogleGenAI, Chat } from "@google/genai";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const systemInstruction = `
You are a world-class personal assistant AI. Your name is 'Astra'.
You are helpful, creative, clever, and very friendly.
Your responses should be concise, informative, and presented in a visually appealing markdown format when appropriate (e.g., using lists, bolding, italics).
You are assisting a user in a web-based chat interface.
`;

export function createChatSession(): Chat {
  const chat: Chat = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: systemInstruction,
    },
  });
  return chat;
}


import React from 'react';
import { Message } from '../types';

interface MessageBubbleProps {
  message: Message;
}

const UserIcon = () => (
    <div className="w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center font-bold text-slate-200 flex-shrink-0">
        U
    </div>
);

const ModelIcon = () => (
    <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-slate-100 flex-shrink-0">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 3a1 1 0 00-1 1v1.172a3.996 3.996 0 00-1.414.878L6.293 4.757a1 1 0 00-1.414 1.414l1.293 1.293A3.996 3.996 0 005.303 9H4a1 1 0 100 2h1.303a3.996 3.996 0 00.878 1.414l-1.293 1.293a1 1 0 101.414 1.414l1.293-1.293A3.996 3.996 0 009 14.697V16a1 1 0 102 0v-1.303a3.996 3.996 0 001.414-.878l1.293 1.293a1 1 0 101.414-1.414l-1.293-1.293A3.996 3.996 0 0014.697 11H16a1 1 0 100-2h-1.303a3.996 3.996 0 00-.878-1.414l1.293-1.293a1 1 0 10-1.414-1.414l-1.293 1.293A3.996 3.996 0 0011 5.303V4a1 1 0 00-1-1zm-1 6a2 2 0 114 0 2 2 0 01-4 0z" clipRule="evenodd" />
        </svg>
    </div>
);

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.role === 'user';
  const isError = message.role === 'error';

  const bubbleClasses = isUser
    ? 'bg-blue-600 text-white'
    : isError
    ? 'bg-red-500/20 text-red-300 border border-red-500/50'
    : 'bg-slate-700 text-slate-200';

  const layoutClasses = isUser ? 'justify-end' : 'justify-start';

  return (
    <div className={`flex items-start gap-3 w-full ${layoutClasses}`}>
      {!isUser && <ModelIcon />}
      <div className={`max-w-xl w-full p-4 rounded-lg prose prose-invert prose-sm ${bubbleClasses}`}>
        {message.content}
      </div>
       {isUser && <UserIcon />}
    </div>
  );
};

export default MessageBubble;

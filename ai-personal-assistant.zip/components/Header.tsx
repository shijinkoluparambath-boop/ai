
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-slate-800/50 backdrop-blur-lg p-4 border-b border-slate-700/50 sticky top-0 z-10">
      <div className="container mx-auto flex items-center gap-3">
         <span className="text-2xl">🤖</span>
        <h1 className="text-xl font-bold text-slate-100">AI Personal Assistant</h1>
      </div>
    </header>
  );
};

export default Header;


export type Role = 'user' | 'model' | 'error';

export interface Message {
  id: string;
  role: Role;
  content: string;
}


import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Chat } from '@google/genai';
import { Message } from './types';
import { createChatSession } from './services/geminiService';
import Header from './components/Header';
import MessageBubble from './components/MessageBubble';
import InputBar from './components/InputBar';
import LoadingIndicator from './components/LoadingIndicator';

const App: React.FC = () => {
  const [chat, setChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setChat(createChatSession());
    const initialMessage: Message = {
      id: 'initial-message',
      role: 'model',
      content: "Hello! I'm Astra, your personal assistant. How can I help you today?",
    };
    setMessages([initialMessage]);
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = useCallback(async (userInput: string) => {
    if (!chat || isLoading) return;

    setIsLoading(true);
    const userMessage: Message = { id: Date.now().toString(), role: 'user', content: userInput };
    setMessages(prev => [...prev, userMessage]);

    try {
      const stream = await chat.sendMessageStream({ message: userInput });

      let modelResponse = '';
      const modelMessageId = (Date.now() + 1).toString();
      
      // Add a placeholder for the AI's response to be updated by the stream
      setMessages(prev => [...prev, { id: modelMessageId, role: 'model', content: '' }]);

      for await (const chunk of stream) {
        const chunkText = chunk.text;
        modelResponse += chunkText;
        setMessages(prev => prev.map(msg => 
            msg.id === modelMessageId ? { ...msg, content: modelResponse } : msg
        ));
      }

      if (modelResponse.trim() === '') {
         setMessages(prev => prev.map(msg => 
            msg.id === modelMessageId ? { ...msg, content: "I'm sorry, I couldn't generate a response. Please try again." } : msg
         ));
      }

    } catch (error) {
      console.error("Error sending message:", error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'error',
        content: 'Sorry, something went wrong. Please check your connection or API key and try again.'
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [chat, isLoading]);


  return (
    <div className="flex flex-col h-screen bg-slate-900 text-white">
      <Header />
      <main className="flex-1 overflow-y-auto p-4">
        <div className="container mx-auto space-y-6">
          {messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} />
          ))}
          {isLoading && messages[messages.length -1]?.role === 'user' && (
             <div className="flex items-start gap-3 justify-start">
                  <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-slate-100 flex-shrink-0">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M10 3a1 1 0 00-1 1v1.172a3.996 3.996 0 00-1.414.878L6.293 4.757a1 1 0 00-1.414 1.414l1.293 1.293A3.996 3.996 0 005.303 9H4a1 1 0 100 2h1.303a3.996 3.996 0 00.878 1.414l-1.293 1.293a1 1 0 101.414 1.414l1.293-1.293A3.996 3.996 0 009 14.697V16a1 1 0 102 0v-1.303a3.996 3.996 0 001.414-.878l1.293 1.293a1 1 0 101.414-1.414l-1.293-1.293A3.996 3.996 0 0014.697 11H16a1 1 0 100-2h-1.303a3.996 3.996 0 00-.878-1.414l1.293-1.293a1 1 0 10-1.414-1.414l-1.293 1.293A3.996 3.996 0 0011 5.303V4a1 1 0 00-1-1zm-1 6a2 2 0 114 0 2 2 0 01-4 0z" clipRule="evenodd" />
                      </svg>
                  </div>
                  <div className="max-w-xl w-full p-4 rounded-lg bg-slate-700">
                    <LoadingIndicator />
                  </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>
      <InputBar onSendMessage={handleSendMessage} isLoading={isLoading} />
    </div>
  );
};

export default App;
